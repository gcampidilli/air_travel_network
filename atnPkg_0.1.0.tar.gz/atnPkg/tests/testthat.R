library(testthat)
library(atnPkg)

test_check("atnPkg")
